﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    class FileQuery
    {

        private enum QueryType { Version, Size, Unknown };
        public enum QueryReturnType { String, Int, Bool, Object, Null };

        public QueryReturnType ReturnValueType;
        private QueryType Type;

        private string FilePath;

        private FileDetails FileDetails;

        public FileQuery(string fileQuery, string filePath)
        {
            Type = GetQueryType(fileQuery);
            SetReturnValueType();
            FilePath = filePath;
        }

        public object QueryFile()
        {
            switch (Type)
            {
                case (QueryType.Size):
                    return GetFileSize(FilePath);
                case (QueryType.Version):
                    return GetVersion(FilePath);
                default:
                    return null;
            }
        }

        private int GetVersion(string filepath)
        {
            FileDetails = new FileDetails();
            return FileDetails.Size(filepath);
        }

        private int GetFileSize(string filepath)
        {
            FileDetails = new FileDetails();
            return FileDetails.Size(filepath);
        }

        private void SetReturnValueType()
        {
            switch (Type)
            {
                case (QueryType.Size):
                    {
                        ReturnValueType = QueryReturnType.Int;
                        break;
                    }
                case (QueryType.Version):
                    {
                        ReturnValueType = QueryReturnType.String;
                        break;
                    }
                case (QueryType.Unknown):
                    {
                        ReturnValueType = QueryReturnType.Object;
                        break;
                    }
            }
        }

        private static QueryType GetQueryType(string fileQuery)
        {
            switch (fileQuery)
            {
                case ("-v"):
                case ("--v"):
                case ("/v"):
                case ("version"):
                    return QueryType.Version;

                case ("-s"):
                case ("--s"):
                case ("/s"):
                case ("size"):
                    return QueryType.Size;

            }
            return QueryType.Unknown;
        }
    }
}
