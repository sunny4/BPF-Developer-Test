﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            string FileQuery = args[0];
            string FilePath = args[1];
            FileQuery fileQuery = new FileQuery(FileQuery, FilePath);

            fileQuery.QueryFile();
        }
    }
}
